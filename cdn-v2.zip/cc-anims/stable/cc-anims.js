/* cc-anims v1.0.0 - sibling module loader */
(function () {
  "use strict";

  const cfg = window.CCAnims || {};

  // Prevent double-init
  if (window.__CC_ANIMS_INIT__) return;
  window.__CC_ANIMS_INIT__ = true;

  // Figure out CDN root from this script URL:
  // https://cdn.example.com/cc-anims/stable/cc-anims.js  -> root = https://cdn.example.com
  const thisSrc = (document.currentScript && document.currentScript.src) || "";
  const root = thisSrc.includes("/cc-anims/")
    ? thisSrc.split("/cc-anims/")[0]
    : "";

  // Optional override (handy for self-host or mirrors)
  const cdnRoot = cfg.cdnRoot || root;

  // A tiny registry to avoid injecting duplicates
  window.__CC_ANIMS_LOADED__ = window.__CC_ANIMS_LOADED__ || { css: {}, js: {} };

  function loadCSS(href, key) {
    const k = key || href;
    if (window.__CC_ANIMS_LOADED__.css[k]) return;
    window.__CC_ANIMS_LOADED__.css[k] = true;

    const el = document.createElement("link");
    el.rel = "stylesheet";
    el.href = href;
    document.head.appendChild(el);
  }

  function loadJS(src, key) {
    const k = key || src;
    if (window.__CC_ANIMS_LOADED__.js[k]) return;
    window.__CC_ANIMS_LOADED__.js[k] = true;

    const el = document.createElement("script");
    el.src = src;
    el.defer = true;
    document.head.appendChild(el);
  }

  // Helper: allows { enabled:true, version:"2.0.0" } OR true/false
  function isEnabled(val) {
    if (val === true) return true;
    if (!val) return false;
    if (typeof val === "object" && val.enabled === true) return true;
    return false;
  }

  function getVersion(val) {
    if (typeof val === "object" && val.version) return String(val.version);
    return "stable";
  }

  // Map: module -> files
  // Keep modules standalone: each module folder owns its CSS/JS.
  function moduleBase(name, version) {
    return `${cdnRoot}/${name}/${version}/`;
  }

  // --- Modules (OFF by default) ---

  // cc-reveal
  if (isEnabled(cfg.reveal)) {
    const v = getVersion(cfg.reveal);
    const base = moduleBase("cc-reveal", v);
    loadCSS(base + "cc-reveal.css", `cc-reveal:${v}:css`);
    loadJS(base + "cc-reveal.js", `cc-reveal:${v}:js`);
  }

  // cc-goldust
  if (isEnabled(cfg.goldust)) {
    const v = getVersion(cfg.goldust);
    const base = moduleBase("cc-goldust", v);
    loadCSS(base + "cc-goldust.css", `cc-goldust:${v}:css`);
    loadJS(base + "cc-goldust.js", `cc-goldust:${v}:js`);
  }

  // Future modules (example placeholders)
  // if (isEnabled(cfg.sparkle)) { ... }
  // if (isEnabled(cfg.parallax)) { ... }

})();